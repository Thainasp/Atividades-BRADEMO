import 'package:flutter/material.dart';
import 'package:exercicio03/widgets/login_form.dart';
import 'package:exercicio03/screens/home_screen.dart';
import 'package:exercicio03/models/login.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  void _handleLogin(BuildContext context, Login login) {
    if (login.isValid()) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => const HomeScreen()),
      );
    } else {
      ScaffoldMessenger.of(context)
        ..removeCurrentSnackBar()
        ..showSnackBar(
          const SnackBar(
            content: Text('Falha no login: Usuário ou senha incorretos!'),
            backgroundColor: Colors.redAccent,
          ),
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Login Page'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 40),
        child: Column(
          children: [
            const SizedBox(
              height: 120,
              child: FlutterLogo(size: 100, style: FlutterLogoStyle.horizontal),
            ),
            const SizedBox(height: 30),

            LoginForm(
              onLogin: (loginData) => _handleLogin(context, loginData),
            ),
          ],
        ),
      ),
    );
  }
}